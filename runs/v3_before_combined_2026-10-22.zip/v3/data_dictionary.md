# V3 data dictionary

| Field / file | Meaning |
|---|---|
| record_key, review_id, app_id, platform | Source identity; record_key is unique within the saved merged set. |
| text, title | Verbatim body and optional Apple title; title may be null. |
| rating | Source integer 1–5. |
| review_timestamp_seconds | Source Unix seconds; sort key descending. |
| review_time_hk, review_time_utc | The same instant with explicit timezone. |
| collected_at_utc | Capture time, distinct from review date. |
| request_language, request_country | Retrieval locale and HK storefront; not language/location proof. |
| language_status, language_method | Preserved original English detector decision. |
| analysis_language, analysis_language_method | V3 routing: english / chinese / mixed / excluded, with reason. |
| within_six_month_window | HKT half-open date-window decision. |
| source_url | Public review or listing link; Apple usually lacks a direct review permalink. |
| raw_response_workspace_path, raw_item_index, raw_entry_index | Exact raw file and source position, relative to v3/. |
| source_observations | Capture references per review ID, retained through deduplication. |
| rating_sentiment | Star-based negative / neutral / positive proxy. |
| text_sentiment_rule | Supplementary English lexicon; Chinese/mixed = not_evaluated_chinese. |
| text_sentiment_evaluated_count | English-only denominator for supplementary text polarity. |
| themes, theme_labels | Multi-label keyword mentions, not confirmed complaints. |
| short_text_for_theme_review | At most 4 Latin words and at most 8 Han characters. |
| language_scope | all / english / chinese (includes mixed) / mixed (subset). |
| review_count, mean_rating | Group denominator and review sample mean, not lifetime listing rating. |
| negative_count_rating_1_2, negative_rate_rating_1_2 | Low-star record count and count / group reviews. |
| theme_mentions, theme_mention_rate | Topic hits and hits / bank-store-language reviews. |
| theme_negative_count, theme_negative_rate | Low-star hits and low-star hits / theme mentions. |
| benchmark_deltas | SC minus HSBC or BOCHK, within the same store/language. |
| data/qa/exclusions | Outside-window or unsupported/uncertain language records. |
| data/qa/capture_variants | Alternate snapshots with differing source-content fingerprints. |

CSV and JSON share row order; arrays/objects are JSON strings in CSV/Excel. CSV is faithful text and can contain formula-looking comments; Excel is the typed, non-executable workbook for spreadsheet browsing. Empty rate/mean denominators are null in JSON and N/A in the HTML.
