# Hong Kong Banking App Feedback Monitor — V3

Open **report_customer_feedback_v3.html** locally. No server, login or network is required. The interface and documentation are English; Chinese and English customer comments remain in their source wording.

Select an app store and a review language at the top. Both selectors update all metrics, two benchmark comparisons, topics, monthly results, examples and comments. The bank/rating/topic/search controls below affect comments only. Chinese includes mixed; mixed-only is a subset. Do not add mixed a second time.

- Management brief: executive_summary.md.
- Workbook: data/reviews_v3.xlsx, with separate Google/Apple review sheets.
- All included source reviews: data/merged/master_bilingual_six_months.csv and .json, newest first.
- Reviews with analysis labels: data/analysis/comment_labels.csv and .json.
- Separate store/bank tables: data/stores/.
- All-date/all-language evidence: data/merged/master_all_reviews.*.
- Capture evidence: data/raw/imported/ and data/chinese_collection/.
- Scope and methods: config.json, methodology.md, data_dictionary.md and checkpoints A–F.
- Validation: manual_review.json, validation/, screenshots/ and manifest.json.

Included: 1,682 records; window: 2026-04-19 through 2026-10-19 inclusive HKT. Latest included observation: 2026-10-19T22:24:46+08:00. There are 25 window records excluded for uncertain or unsupported language; raw evidence remains saved.

V1 and V2 are unchanged. V3 adapts the project Skill's English/two-app engine with a separate bilingual routing/rule layer and three-bank, store-specific reporting. The installed Skill itself has not been upgraded; use the V3 scripts for this scope.

## Reproduce from the saved input

Use the project Python environment, which contains google-play-scraper 1.2.7 and langdetect 1.0.9. From the project root:

```powershell
.\.venv\Scripts\python.exe -B v3/scripts/pipeline.py prepare
# Read validation_sample.json; update manual_review.json with actual judgments if it changes.
.\.venv\Scripts\python.exe -B v3/scripts/pipeline.py build
.\.venv\Scripts\python.exe -B v3/scripts/pipeline.py verify
.\.venv\Scripts\python.exe -B v3/scripts/browser_check.py
# Inspect the actual screenshots and update validation/visual_inspection.json.
.\.venv\Scripts\python.exe -B v3/scripts/pipeline.py finalize
```

`import` and `collect_chinese.py` are first-run stages only. They reject existing batches to preserve evidence. A future live update must use a new capture directory and appropriate dates. Do not overwrite raw responses or reuse old reading/visual approvals for changed samples or HTML. Offline reproduction does not make a new live coverage claim. Browser verification requires installed Edge or Chrome.
