# Checkpoint A — V3 source feasibility

Requirement: include Chinese-language customer reviews; preserve English manager delivery, HSBC HK + BOCHK benchmarks, separate stores and the existing window.

Verified app IDs from the preserved configuration: SC Google com.scb.breezebanking.hk / Apple 445795688; HSBC hk.com.hsbc.hsbchkmobilebanking / 1164066737; BOCHK com.bochk.app.aos / 1534534188. Live zh-HK and zh-CN Google requests completed for all three on 22 October. Apple HK saved feeds already contain Chinese and are reused. Sources are bounded and are suitable for sample monitoring; complete history is not established.
