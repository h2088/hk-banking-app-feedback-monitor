# Checkpoint B — V3 collection and quality

Imported 6,378 unique V2 records and their referenced raw evidence; added 3,585 Chinese-locale Google observations. Six jobs completed, stopped on older-page boundaries or endpoint exhaustion. Summary and each raw HTTP response are saved under data/chinese_collection/; no Apple recollection was necessary.

Saved unique records: 9,963; window all-language records: 1,707; selected bilingual records: 1,682; language exclusions in the window: 25. Duplicate observations: 0; capture variants: 0. Every source record retains capture time, review time, parameters and raw reference. V1 and V2 are protected by 2,020 recorded hashes.

| Store | Bank | English | Chinese, incl. mixed | Total | Mean rating | 1–2 star share |
|---|---|---:|---:|---:|---:|---:|
| Google Play | SC Mobile | 62 | 140 | 202 | 1.92 | 73.8% |
| Google Play | HSBC HK | 127 | 251 | 378 | 3.01 | 45.2% |
| Google Play | BOCHK | 77 | 369 | 446 | 2.76 | 51.1% |
| Apple App Store | SC Mobile | 50 | 58 | 108 | 2.29 | 63.0% |
| Apple App Store | HSBC HK | 121 | 146 | 267 | 3.37 | 38.2% |
| Apple App Store | BOCHK | 60 | 221 | 281 | 2.93 | 48.8% |
