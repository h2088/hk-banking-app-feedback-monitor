# V3 methodology and limits

## Scope and sources

Monitor and report customer comments for SC Mobile Hong Kong, benchmarked against HSBC HK Mobile Banking and BOCHK. Use the HK storefront and `[2026-04-19T00:00:00+08:00, 2026-10-20T00:00:00+08:00)`. Google Play and Apple App Store always have separate denominators. No social media, live alerting, production scheduler or verified incident severity is included.

V2 supplies 6,378 unique records across dates/languages with saved raw HTTP evidence. Google Play adds zh-HK and zh-CN requests for each bank, newest first, 200 per page, at most two concurrent jobs. Stop after two pages entirely before the window, endpoint exhaustion or the bounded page/error policy. The six requests returned 3,585 observations on 22 October. Apple HK RSS snapshots already include Chinese, so changing UI language is unnecessary. SC/HSBC Apple snapshots remain from 19 October; BOCHK from 22 October. BOCHK accepted 500 records on pages 1–10; boundary page 11 returned HTTP 400.

The imported source parsers and collectors are reused from the app-review-feedback Skill. A locale is a retrieval parameter, not an author language guarantee, author location, complete history or proof that results could be obtained on 19 October. Bounded public feeds can omit records. Capture dates differ and later snapshots cannot recover historical edits/deletions.

## Identity, original text and QA

Unique key: platform + app ID + review ID. V2 wins on overlap, then first zh-HK observation, then zh-CN. All source observations stay saved; differing body/title/rating/time fingerprints go to capture_variants. This batch found 0 duplicate observations and 0 differing variants; do not assume later runs will have the same overlap. There are 9,963 unique saved records and 1,707 window records across languages. Different IDs with the same text are retained (49 repeated-text groups in the included set).

`text` is the original customer body. Apple `title` supplements matching/search and remains separate. No source translation, spelling correction or Traditional/Simplified conversion is stored. Developer replies are not customer comments. The HTML excludes display names and developer replies; full raw/data evidence can contain them. Empty historical bodies remain saved and excluded. All included title/body/rating/time values are checked against their exact saved raw responses. CSV uses UTF-8 BOM; Excel uses typed, formula-safe cells. Sort by descending source timestamp, then stable record key.

## Review-language routing

The original detector output is preserved in language_status; V3's separate analysis_language controls inclusion. Han script without kana/Hangul is routed as Chinese. At least three distinct Latin words excluding a documented acronym list triggers mixed. The threshold avoids counting a repeated Apple title as extra English evidence. Both Chinese and mixed belong to the Chinese-inclusive view. Source script is not normalized for storage.

This HK-context heuristic can confuse Han-only Japanese and can call device/version identifiers mixed. Short English insertions can remain Chinese. It does not infer Traditional/Simplified exclusively, because these scripts overlap and reviews can mix them. Kana/Hangul records are excluded conservatively. Non-Han records use the preserved English decisions plus 15 exact-body English phrase decisions actually read by the Codex agent (ENGLISH_OVERRIDES in bilingual_rules.py). Shared 'ok', emoji, gibberish and uncertain fragments are not forced into English. The override is an interpretation, not an independent human label. All 418 English V2 fingerprints are preserved.

## Sentiment and themes

Primary sentiment is source rating: 1–2 negative, 3 neutral, 4–5 positive. It measures stars in review samples and can disagree with the text. An English lexicon is retained as supplementary fields for English only. Chinese/mixed text polarity is **not evaluated**; its numeric fields are null and it is excluded from the English lexicon denominator.

Eleven overlapping themes use V2 English regex plus explicit Traditional/Simplified/Cantonese terms in bilingual_rules.py. Matching uses an NFKC copy. A matching-only boundary is inserted between Han and Latin characters so '一直loading' and 'password之後' can match English terms. Original text is unchanged. Chinese additions include '彈app', '轉款', identity/login terms and waiting/loading expressions. Standalone Chinese '服務' is not a customer-support trigger; unavailable online service can instead match stability. Standalone '功能/增加' does not establish a feature request.

Rules do not understand negation, irony, cause, ownership or severity. '不应该出现' can still trigger a suggestion term; 'wait long long time' can miss performance; a marketing complaint can remain unclassified. Features, security checks and notifications can overmatch broad English patterns. A positive usability mention is not a complaint. Short and unclassified comments remain included (615 short for triage; 502 unclassified). These are screening labels, not complaint or incident counts.

## Metrics and validation

For each bank/store/language group, mean rating is sum of stars / reviews; low-star share is 1–2 star count / reviews. Theme mention share divides by group reviews. Theme low-star share divides by theme mentions. Monthly denominators use the same bank/store/language within each HKT month; April/October are partial. Empty group rates/means are null and display N/A. Benchmark differences are SC minus the benchmark in the same store and language view, in stars or percentage points. Mixed is a subset of Chinese, so do not sum all four language scopes.

47 comments were selected across store, bank, actual language category and available 1/3/5-star levels, newest first within each stratum. The Codex agent actually read and recorded individual notes with source fingerprints. This is a deliberate triage sample, not a random validation set or independent human accuracy study. Static checks independently recompute denominators and validate all source rows; real-browser checks cover every included original comment, all language/store views, filtering, pagination, empty states, literal markup, offline operation and narrow layout. Screenshots must be viewed and signed for the exact report hash before finalization.

No population satisfaction, statistical significance, unique-customer counts, causality, confirmed incidents, loss estimates or complete-coverage claims follow from these samples. Compare English and Chinese views to assess composition; validate candidate journeys against telemetry, release/device information and support cases.
