# Hong Kong Banking App Feedback Monitor — V3

V3 adds Chinese-language customer reviews while retaining English management reporting, separate Google Play and Apple App Store comparisons, and both HSBC HK and BOCHK as benchmarks for SC Mobile. The review-date window remains **19 April–19 October 2026 inclusive, Hong Kong time**.

The analysis includes **1,682 review records**: 497 English and 1,185 Chinese including 63 mixed records. All 418 V2 English records are preserved exactly. Additional locale requests and reviewed English boundary cases raise the English view to 497; it is not an unchanged V2 population.

| Store | Bank | English | Chinese, incl. mixed | Total | Mean rating | 1–2 star share |
|---|---|---:|---:|---:|---:|---:|
| Google Play | SC Mobile | 62 | 140 | 202 | 1.92 | 73.8% |
| Google Play | HSBC HK | 127 | 251 | 378 | 3.01 | 45.2% |
| Google Play | BOCHK | 77 | 369 | 446 | 2.76 | 51.1% |
| Apple App Store | SC Mobile | 50 | 58 | 108 | 2.29 | 63.0% |
| Apple App Store | HSBC HK | 121 | 146 | 267 | 3.37 | 38.2% |
| Apple App Store | BOCHK | 60 | 221 | 281 | 2.93 | 48.8% |

SC has a higher low-star share and a lower mean rating than both benchmarks within each store in the combined sample.

- Google Play, SC vs HSBC HK: **+28.5 percentage points** in low-star share; -1.09 stars in sample mean.
- Google Play, SC vs BOCHK: **+22.6 percentage points** in low-star share; -0.84 stars in sample mean.
- Apple App Store, SC vs HSBC HK: **+24.8 percentage points** in low-star share; -1.08 stars in sample mean.
- Apple App Store, SC vs BOCHK: **+14.2 percentage points** in low-star share; -0.64 stars in sample mean.

Chinese inclusion affects banks differently. On Google Play, low-star shares in the Chinese-inclusive view are 76.4% for SC, 50.6% for HSBC and 53.7% for BOCHK. On Apple they are 63.8%, 33.6% and 48.4%. Language composition changes the comparison; the report provides English, Chinese-inclusive, mixed-only and combined views to make this visible.

SC themes with the most low-star mentions in the combined view:

- Google Play: App stability / performance — 69 mentions, 60 low-star; Login / authentication / access — 58 mentions, 51 low-star; Transfers / payments / cards — 56 mentions, 43 low-star.
- Apple App Store: Login / authentication / access — 43 mentions, 37 low-star; App stability / performance — 28 mentions, 24 low-star; Transfers / payments / cards — 31 mentions, 18 low-star.

Use these observations to investigate login/identity journeys and stability, then transfer/payment journeys, separately by store. Check source comments, release/device evidence and support tickets before deciding a fix. Topic counts overlap and include positive mentions; no root cause or defect rate is established.

The new Google Chinese captures are dated 22 October; original SC/HSBC snapshots are dated 19 October, and BOCHK 22 October. Apple reuses bounded multi-language HK feeds. This is an analysis of saved public review samples, not a complete historical census or a measure of all customers. See methodology.md for language, rule and coverage limitations.
