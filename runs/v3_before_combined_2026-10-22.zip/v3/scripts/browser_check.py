"""Check the exact delivered V3 HTML in Edge; capture real rendered views."""
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"engine"))
from feedback_io import dump,load,now,sha

HARNESS=r'''
let count=0,failures=[];
function assert(x,label){count++;if(!x)failures.push(label)}
function choose(id,value){$(id).value=value;$(id).dispatchEvent(new Event(id==="searchFilter"?"input":"change"))}
function reset(){$("resetFilters").click()}
function lang(r,l){return l==="all"||(l==="english"&&r.analysis_language==="english")||(l==="chinese"&&["chinese","mixed"].includes(r.analysis_language))||(l==="mixed"&&r.analysis_language==="mixed")}
function expected(){const st=$("storeFilter").value,l=$("languageFilter").value,b=$("bankFilter").value,s=$("sentimentFilter").value,r=$("ratingFilter").value,t=$("themeFilter").value,q=$("searchFilter").value.trim().toLowerCase();return EXPECTED.filter(x=>x.platform===st&&lang(x,l)&&(!b||x.app_key===b)&&(!s||x.rating_sentiment===s)&&(!r||x.rating===Number(r))&&(!t||(t==="unclassified"?!x.themes.length:x.themes.includes(t)))&&(!q||((x.title||"")+"\n"+x.text).toLowerCase().includes(q)))}
function checkView(label){const e=expected(),a=[...$("reviewList").querySelectorAll("article")];assert(a.length===Math.min(25,e.length),label+" page size");assert($("resultCount").textContent.startsWith(e.length+" matching"),label+" total");assert(a.map(n=>n.dataset.key).join("|")===e.slice(0,25).map(r=>r.record_key).join("|"),label+" first-page IDs")}
function rate(rows){return rows.length?100*rows.filter(r=>r.rating<=2).length/rows.length:null}
function formatRate(rows){const x=rate(rows);return x===null?"N/A":x.toFixed(1)+"%"}
try{
assert(document.documentElement.lang==="en","English document");
assert($("languageFilter").options.length===4,"Four language views");
assert(DATA.rows.length===EXPECTED.length,"All source records embedded");
for(const store of ["Google Play","Apple App Store"]){
 for(const scope of ["all","english","chinese","mixed"]){
  reset();choose("storeFilter",store);choose("languageFilter",scope);
  const group=EXPECTED.filter(r=>r.platform===store&&lang(r,scope)),label=store+" "+scope;
  assert($("overviewTitle").textContent.includes(DATA.scopes[scope]),label+" language heading");
  [...$("cards").children].forEach((card,i)=>{const key=APP_KEYS[i],rows=group.filter(r=>r.app_key===key),mean=rows.length?rows.reduce((a,r)=>a+r.rating,0)/rows.length:null;
   assert(card.querySelector(".review-count").textContent===rows.length+" reviews",label+key+" denominator");
   assert(card.querySelector(".score").firstChild.textContent===(mean===null?"N/A":mean.toFixed(2)),label+key+" mean");
   assert(card.querySelector(".measure strong").textContent===formatRate(rows),label+key+" low share");
   for(const l of ["english","chinese","mixed"])assert(card.querySelector(".language-counts").textContent.includes(LANG_NAMES[l]+": "+rows.filter(r=>r.analysis_language===l).length),label+key+l+" composition");
  });
  assert($("comparisons").children.length===2,label+" two benchmarks");
  ["hsbc_hk","bochk"].forEach((key,i)=>{const p=group.filter(r=>r.app_key==="sc_mobile"),b=group.filter(r=>r.app_key===key),gap=p.length&&b.length?rate(p)-rate(b):null,d=DATA.deltas.find(x=>x.platform===store&&x.language_scope===scope&&x.benchmark===APP_NAMES[key]);assert(gap===null?d.low_star_rate_difference_percentage_points===null:Math.abs(gap-d.low_star_rate_difference_percentage_points)<0.0003,label+key+" independent low-star gap");assert($("comparisons").children[i].textContent.includes(APP_NAMES[key]),label+key+" comparison name")});
  assert($("themeBody").children.length===11,label+" 11 topics");
  Object.keys(DATA.theme_names).forEach((theme,i)=>APP_KEYS.forEach((key,col)=>{const rows=group.filter(r=>r.app_key===key),hits=rows.filter(r=>r.themes.includes(theme)),td=$("themeBody").children[i].children[col+1];assert(td.firstChild.textContent===hits.length+" / "+rows.length+" · "+(rows.length?(100*hits.length/rows.length).toFixed(1)+"%":"N/A"),label+key+theme+" topic denominator");assert(td.querySelector("small").textContent===hits.filter(r=>r.rating<=2).length+" low-star mentions",label+key+theme+" low-star topic") }));
  assert($("monthlyBody").children.length===7,label+" seven months");
  for(let m=4;m<=10;m++)APP_KEYS.forEach((key,col)=>{const bucket="2026-"+String(m).padStart(2,"0"),rows=group.filter(r=>r.app_key===key&&r.review_time_hk.startsWith(bucket)),td=$("monthlyBody").children[m-4].children[col+1];assert(td.firstChild.textContent===formatRate(rows),label+key+bucket+" monthly share");assert(td.querySelector("small").textContent.startsWith(rows.filter(r=>r.rating<=2).length+" / "+rows.length+" reviews"),label+key+bucket+" monthly denominator")});
  checkView(label+" initial");
  for(const b of APP_KEYS){choose("bankFilter",b);checkView(label+b)}reset();
  for(const r of ["1","2","3","4","5"]){choose("ratingFilter",r);checkView(label+" rating "+r)}reset();
  for(const s of ["negative","neutral","positive"]){choose("sentimentFilter",s);checkView(label+s)}reset();
  for(const t of [...Object.keys(DATA.theme_names),"unclassified"]){choose("themeFilter",t);checkView(label+t)}reset();
  for(const q of ["login","登入","转账","閃退","GOOD","no-match-123456789"]){choose("searchFilter",q);checkView(label+" query "+q)}reset();
  choose("bankFilter","bochk");choose("ratingFilter","1");choose("themeFilter","login_authentication_access");choose("sentimentFilter","negative");checkView(label+" combined");reset();
  choose("searchFilter","no-match-123456789");assert(!!$("reviewList").querySelector(".empty"),label+" empty message");assert($("prevPage").disabled&&$("nextPage").disabled,label+" empty controls");reset();
  if(scope==="all"){
   const seen=[];do{for(const node of $("reviewList").querySelectorAll("article")){const r=EXPECTED.find(x=>x.record_key===node.dataset.key);assert(!!r,label+" known ID");if(r){assert(node.querySelector(".review-body").textContent===r.text,r.record_key+" Unicode body");assert((node.querySelector(".review-title")?.textContent||"")===(r.title||""),r.record_key+" Unicode title");assert(node.querySelector("a").href===r.source_url,r.record_key+" source link");assert(node.querySelector(".language-tag").textContent===LANG_NAMES[r.analysis_language],r.record_key+" language badge");assert(node.querySelector(".review-meta").textContent.includes(r.review_time_hk.replace("T"," ").replace("+08:00"," HKT")),r.record_key+" source time");seen.push(r.record_key)}}if($("nextPage").disabled)break;$("nextPage").click()}while(seen.length<EXPECTED.length+25);
   assert(seen.join("|")===group.map(r=>r.record_key).join("|"),label+" all pages newest first");reset();
  }
  assert(document.documentElement.scrollWidth<=innerWidth,label+" no page overflow");
 }
}
const attack={...DATA.rows[0],record_key:"synthetic:escaping",analysis_language:"chinese",text:'中文 literal <img src=x onerror="window.__attack=1">',title:'<svg onload="window.__attack=1">',themes:[],theme_labels:[]};DATA.rows.unshift(attack);choose("languageFilter","all");choose("storeFilter",attack.platform);choose("searchFilter","中文 literal");assert($("reviewList").querySelector(".review-body").textContent===attack.text,"literal untrusted body");assert($("reviewList").querySelector(".review-title").textContent===attack.title,"literal untrusted title");assert(!$("reviewList").querySelector("img,svg,script")&&!window.__attack,"no source markup execution");DATA.rows.shift();reset();
// Force a genuinely empty bank/language group in a temporary in-memory test.
const saved=DATA.groups.find(x=>x.platform==="Google Play"&&x.language_scope==="mixed"&&x.app_key==="sc_mobile");const old={...saved};Object.assign(saved,{review_count:0,mean_rating:null,negative_rate_rating_1_2:null,negative_count_rating_1_2:0,positive_count_rating_4_5:0});choose("storeFilter","Google Play");choose("languageFilter","mixed");assert($("cards").firstChild.querySelector(".score").firstChild.textContent==="N/A","empty group mean N/A");assert($("cards").firstChild.querySelector(".measure strong").textContent==="N/A","empty group rate N/A");Object.assign(saved,old);
assert(performance.getEntriesByType("resource").length===0,"No network subresources");
}catch(e){failures.push(String(e.stack||e))}
const out=document.createElement("script");out.type="application/json";out.id="browserTestResults";out.textContent=JSON.stringify({passed:!failures.length,assertions:count,failures,network_subresources:performance.getEntriesByType("resource").length});document.body.append(out);
'''

def main():
    browser=Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe")
    assert browser.is_file()
    report=ROOT/"report_customer_feedback_v3.html"
    document=report.read_text(encoding="utf-8")
    fields=["record_key","platform","app_key","rating","title","text","review_time_hk","source_url","rating_sentiment","themes","analysis_language"]
    expected=json.dumps([{k:r.get(k) for k in fields} for r in load(ROOT/"data/analysis/comment_labels.json")],ensure_ascii=True).replace("<","\\u003c").replace(">","\\u003e").replace("&","\\u0026")
    folder=ROOT/"screenshots"
    folder.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="hk_v3_browser_") as tmp:
        tmp=Path(tmp)
        base=[str(browser),"--headless=new","--no-first-run","--disable-extensions","--disable-background-networking","--disable-component-update","--disable-sync","--allow-file-access-from-files"]
        test=tmp/"browser_test.html"
        test.write_text(document.replace("</body>","<script>const EXPECTED="+expected+";\n"+HARNESS+"</script></body>"),encoding="utf-8")
        run=subprocess.run(base+["--user-data-dir="+str(tmp/"test_profile"),"--window-size=1440,1150","--dump-dom","--virtual-time-budget=2500",test.as_uri()],capture_output=True,timeout=55)
        match=re.search(r'<script type="application/json" id="browserTestResults">(.*?)</script>',run.stdout.decode("utf-8",errors="replace"),re.S)
        if not match:
            dump(ROOT/"validation/browser_results.json",dict(passed=False,report_sha256=sha(report),reason="No browser result",stderr=run.stderr.decode("utf-8",errors="replace")[-3000:]))
            raise RuntimeError("No browser result")
        results=json.loads(match.group(1))
        results.update(checked_at_utc=now(),browser=str(browser),report_sha256=sha(report),screenshot_hashes={})
        dump(ROOT/"validation/browser_results.json",results)
        assert results["passed"],results["failures"][:15]
        print(json.dumps(dict(passed=True,assertions=results["assertions"])),flush=True)
        views=[("google_play_combined","Google Play","all","overview",1440),("apple_combined","Apple App Store","all","overview",1440),("apple_chinese_comments","Apple App Store","chinese","reviews",1440),("apple_chinese_topics","Apple App Store","chinese","topics",1440),("narrow_google_play","Google Play","all","overview",600)]
        for name,store,scope,focus,width in views:
            script='$("storeFilter").value='+json.dumps(store)+';$("languageFilter").value='+json.dumps(scope)+';renderStore();'
            if focus=="reviews":
                script+='$("bankFilter").value="bochk";renderReviews();document.querySelectorAll(".section").forEach(e=>{if(e.id!=="reviewSection")e.style.display="none"});document.querySelector("header").style.padding="16px 24px";'
            if focus=="topics":
                script+='document.querySelectorAll(".section").forEach(e=>{if(!["themeSection","monthlySection"].includes(e.id))e.style.display="none"});document.querySelector("header").style.padding="16px 24px";'
            if width==600:
                script+='const n=document.createElement("script");n.id="narrowResults";n.type="application/json";n.textContent=JSON.stringify({innerWidth,scrollWidth:document.documentElement.scrollWidth});document.body.append(n);'
            variant=tmp/(name+".html")
            variant.write_text(document.replace("</body>","<script>"+script+"</script></body>"),encoding="utf-8")
            img=folder/(name+".png")
            snap=subprocess.run(base+["--user-data-dir="+str(tmp/(name+"_profile")),f"--window-size={width},1150","--hide-scrollbars","--screenshot="+str(img),"--virtual-time-budget=2000",variant.as_uri()],capture_output=True,timeout=45)
            assert snap.returncode==0 and img.stat().st_size>10000,name
            results["screenshot_hashes"][img.relative_to(ROOT).as_posix()]=sha(img)
            if width==600:
                narrow=subprocess.run(base+["--user-data-dir="+str(tmp/"narrow_check"),"--window-size=600,1150","--dump-dom","--virtual-time-budget=2000",variant.as_uri()],capture_output=True,timeout=45)
                m=re.search(r'<script id="narrowResults" type="application/json">(.*?)</script>',narrow.stdout.decode("utf-8",errors="replace"),re.S)
                assert m
                n=json.loads(m.group(1))
                assert 320<=n["innerWidth"]<=800 and n["scrollWidth"]<=n["innerWidth"],n
                results["narrow_viewport"]=n
                results["assertions"]+=1
            print("Saved screenshot "+name,flush=True)
        dump(ROOT/"validation/browser_results.json",results)
        print(json.dumps(dict(passed=True,assertions=results["assertions"],screenshots=len(results["screenshot_hashes"]))))

if __name__=="__main__":
    main()
