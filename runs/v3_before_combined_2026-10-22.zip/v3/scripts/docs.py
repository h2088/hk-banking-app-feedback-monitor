"""English delivery documentation derived from the current V3 data."""
import json
from pathlib import Path


def pct(x):
    return "N/A" if x is None else f"{100*x:.1f}%"


def write_docs(root, data):
    s=data["summary"]
    def write(name,text):
        (root/name).write_text(text.strip()+"\n",encoding="utf-8")
    table="| Store | Bank | English | Chinese, incl. mixed | Total | Mean rating | 1–2 star share |\n|---|---|---:|---:|---:|---:|---:|\n"
    for c in data["coverage"]:
        g=next(g for g in data["groups"] if g["platform"]==c["platform"] and g["app_key"]==c["app_key"] and g["language_scope"]=="all")
        table+=f"| {c['platform']} | {c['app']} | {c['english_count']} | {c['chinese_count']+c['mixed_count']} | {g['review_count']} | {g['mean_rating']:.2f} | {pct(g['negative_rate_rating_1_2'])} |\n"
    gaps=[]
    for d in data["deltas"]:
        if d["language_scope"]=="all":
            gaps.append(f"- {d['platform']}, SC vs {d['benchmark']}: **{d['low_star_rate_difference_percentage_points']:+.1f} percentage points** in low-star share; {d['mean_rating_difference_sc_minus_benchmark']:+.2f} stars in sample mean.")
    tops=[]
    for store in ("Google Play","Apple App Store"):
        themes=sorted([t for t in data["themes"] if t["platform"]==store and t["app_key"]=="sc_mobile" and t["language_scope"]=="all"],key=lambda t:(-t["theme_negative_count"],-t["theme_mentions"]))[:3]
        tops.append(f"- {store}: "+"; ".join(f"{t['theme_label'] if 'theme_label' in t else data['theme_names'][t['theme']]} — {t['theme_mentions']} mentions, {t['theme_negative_count']} low-star" for t in themes)+".")
    write("executive_summary.md",f"""
# Hong Kong Banking App Feedback Monitor — V3

V3 adds Chinese-language customer reviews while retaining English management reporting, separate Google Play and Apple App Store comparisons, and both HSBC HK and BOCHK as benchmarks for SC Mobile. The review-date window remains **19 April–19 October 2026 inclusive, Hong Kong time**.

The analysis includes **{s['included_records']:,} review records**: {s['language_counts']['english']} English and {s['language_counts']['chinese']+s['language_counts']['mixed']:,} Chinese including {s['language_counts']['mixed']} mixed records. All 418 V2 English records are preserved exactly. Additional locale requests and reviewed English boundary cases raise the English view to {s['language_counts']['english']}; it is not an unchanged V2 population.

{table}
SC has a higher low-star share and a lower mean rating than both benchmarks within each store in the combined sample.

{chr(10).join(gaps)}

Chinese inclusion affects banks differently. On Google Play, low-star shares in the Chinese-inclusive view are 76.4% for SC, 50.6% for HSBC and 53.7% for BOCHK. On Apple they are 63.8%, 33.6% and 48.4%. Language composition changes the comparison; the report provides English, Chinese-inclusive, mixed-only and combined views to make this visible.

SC themes with the most low-star mentions in the combined view:

{chr(10).join(tops)}

Use these observations to investigate login/identity journeys and stability, then transfer/payment journeys, separately by store. Check source comments, release/device evidence and support tickets before deciding a fix. Topic counts overlap and include positive mentions; no root cause or defect rate is established.

The new Google Chinese captures are dated 22 October; original SC/HSBC snapshots are dated 19 October, and BOCHK 22 October. Apple reuses bounded multi-language HK feeds. This is an analysis of saved public review samples, not a complete historical census or a measure of all customers. See methodology.md for language, rule and coverage limitations.
""")
    write("README.md",f"""
# Hong Kong Banking App Feedback Monitor — V3

Open **report_customer_feedback_v3.html** locally. No server, login or network is required. The interface and documentation are English; Chinese and English customer comments remain in their source wording.

Select an app store and a review language at the top. Both selectors update all metrics, two benchmark comparisons, topics, monthly results, examples and comments. The bank/rating/topic/search controls below affect comments only. Chinese includes mixed; mixed-only is a subset. Do not add mixed a second time.

- Management brief: executive_summary.md.
- Workbook: data/reviews_v3.xlsx, with separate Google/Apple review sheets.
- All included source reviews: data/merged/master_bilingual_six_months.csv and .json, newest first.
- Reviews with analysis labels: data/analysis/comment_labels.csv and .json.
- Separate store/bank tables: data/stores/.
- All-date/all-language evidence: data/merged/master_all_reviews.*.
- Capture evidence: data/raw/imported/ and data/chinese_collection/.
- Scope and methods: config.json, methodology.md, data_dictionary.md and checkpoints A–F.
- Validation: manual_review.json, validation/, screenshots/ and manifest.json.

Included: {s['included_records']:,} records; window: 2026-04-19 through 2026-10-19 inclusive HKT. Latest included observation: {max(r['review_time_hk'] for r in data['rows'])}. There are {s['window_all_languages']-s['included_records']} window records excluded for uncertain or unsupported language; raw evidence remains saved.

V1 and V2 are unchanged. V3 adapts the project Skill's English/two-app engine with a separate bilingual routing/rule layer and three-bank, store-specific reporting. The installed Skill itself has not been upgraded; use the V3 scripts for this scope.

## Reproduce from the saved input

Use the project Python environment, which contains google-play-scraper 1.2.7 and langdetect 1.0.9. From the project root:

```powershell
.\\.venv\\Scripts\\python.exe -B v3/scripts/pipeline.py prepare
# Read validation_sample.json; update manual_review.json with actual judgments if it changes.
.\\.venv\\Scripts\\python.exe -B v3/scripts/pipeline.py build
.\\.venv\\Scripts\\python.exe -B v3/scripts/pipeline.py verify
.\\.venv\\Scripts\\python.exe -B v3/scripts/browser_check.py
# Inspect the actual screenshots and update validation/visual_inspection.json.
.\\.venv\\Scripts\\python.exe -B v3/scripts/pipeline.py finalize
```

`import` and `collect_chinese.py` are first-run stages only. They reject existing batches to preserve evidence. A future live update must use a new capture directory and appropriate dates. Do not overwrite raw responses or reuse old reading/visual approvals for changed samples or HTML. Offline reproduction does not make a new live coverage claim. Browser verification requires installed Edge or Chrome.
""")
    write("methodology.md",f"""
# V3 methodology and limits

## Scope and sources

Monitor and report customer comments for SC Mobile Hong Kong, benchmarked against HSBC HK Mobile Banking and BOCHK. Use the HK storefront and `[2026-04-19T00:00:00+08:00, 2026-10-20T00:00:00+08:00)`. Google Play and Apple App Store always have separate denominators. No social media, live alerting, production scheduler or verified incident severity is included.

V2 supplies {6378:,} unique records across dates/languages with saved raw HTTP evidence. Google Play adds zh-HK and zh-CN requests for each bank, newest first, 200 per page, at most two concurrent jobs. Stop after two pages entirely before the window, endpoint exhaustion or the bounded page/error policy. The six requests returned {s['new_locale_observations']:,} observations on 22 October. Apple HK RSS snapshots already include Chinese, so changing UI language is unnecessary. SC/HSBC Apple snapshots remain from 19 October; BOCHK from 22 October. BOCHK accepted 500 records on pages 1–10; boundary page 11 returned HTTP 400.

The imported source parsers and collectors are reused from the app-review-feedback Skill. A locale is a retrieval parameter, not an author language guarantee, author location, complete history or proof that results could be obtained on 19 October. Bounded public feeds can omit records. Capture dates differ and later snapshots cannot recover historical edits/deletions.

## Identity, original text and QA

Unique key: platform + app ID + review ID. V2 wins on overlap, then first zh-HK observation, then zh-CN. All source observations stay saved; differing body/title/rating/time fingerprints go to capture_variants. This batch found {s['duplicate_observations']} duplicate observations and {s['capture_variant_count']} differing variants; do not assume later runs will have the same overlap. There are {s['unique_fetched_records']:,} unique saved records and {s['window_all_languages']:,} window records across languages. Different IDs with the same text are retained ({s['repeated_text_group_count']} repeated-text groups in the included set).

`text` is the original customer body. Apple `title` supplements matching/search and remains separate. No source translation, spelling correction or Traditional/Simplified conversion is stored. Developer replies are not customer comments. The HTML excludes display names and developer replies; full raw/data evidence can contain them. Empty historical bodies remain saved and excluded. All included title/body/rating/time values are checked against their exact saved raw responses. CSV uses UTF-8 BOM; Excel uses typed, formula-safe cells. Sort by descending source timestamp, then stable record key.

## Review-language routing

The original detector output is preserved in language_status; V3's separate analysis_language controls inclusion. Han script without kana/Hangul is routed as Chinese. At least three distinct Latin words excluding a documented acronym list triggers mixed. The threshold avoids counting a repeated Apple title as extra English evidence. Both Chinese and mixed belong to the Chinese-inclusive view. Source script is not normalized for storage.

This HK-context heuristic can confuse Han-only Japanese and can call device/version identifiers mixed. Short English insertions can remain Chinese. It does not infer Traditional/Simplified exclusively, because these scripts overlap and reviews can mix them. Kana/Hangul records are excluded conservatively. Non-Han records use the preserved English decisions plus 15 exact-body English phrase decisions actually read by the Codex agent (ENGLISH_OVERRIDES in bilingual_rules.py). Shared 'ok', emoji, gibberish and uncertain fragments are not forced into English. The override is an interpretation, not an independent human label. All 418 English V2 fingerprints are preserved.

## Sentiment and themes

Primary sentiment is source rating: 1–2 negative, 3 neutral, 4–5 positive. It measures stars in review samples and can disagree with the text. An English lexicon is retained as supplementary fields for English only. Chinese/mixed text polarity is **not evaluated**; its numeric fields are null and it is excluded from the English lexicon denominator.

Eleven overlapping themes use V2 English regex plus explicit Traditional/Simplified/Cantonese terms in bilingual_rules.py. Matching uses an NFKC copy. A matching-only boundary is inserted between Han and Latin characters so '一直loading' and 'password之後' can match English terms. Original text is unchanged. Chinese additions include '彈app', '轉款', identity/login terms and waiting/loading expressions. Standalone Chinese '服務' is not a customer-support trigger; unavailable online service can instead match stability. Standalone '功能/增加' does not establish a feature request.

Rules do not understand negation, irony, cause, ownership or severity. '不应该出现' can still trigger a suggestion term; 'wait long long time' can miss performance; a marketing complaint can remain unclassified. Features, security checks and notifications can overmatch broad English patterns. A positive usability mention is not a complaint. Short and unclassified comments remain included ({s['short_text_count']} short for triage; {s['unclassified_count']} unclassified). These are screening labels, not complaint or incident counts.

## Metrics and validation

For each bank/store/language group, mean rating is sum of stars / reviews; low-star share is 1–2 star count / reviews. Theme mention share divides by group reviews. Theme low-star share divides by theme mentions. Monthly denominators use the same bank/store/language within each HKT month; April/October are partial. Empty group rates/means are null and display N/A. Benchmark differences are SC minus the benchmark in the same store and language view, in stars or percentage points. Mixed is a subset of Chinese, so do not sum all four language scopes.

{s['sample_count']} comments were selected across store, bank, actual language category and available 1/3/5-star levels, newest first within each stratum. The Codex agent actually read and recorded individual notes with source fingerprints. This is a deliberate triage sample, not a random validation set or independent human accuracy study. Static checks independently recompute denominators and validate all source rows; real-browser checks cover every included original comment, all language/store views, filtering, pagination, empty states, literal markup, offline operation and narrow layout. Screenshots must be viewed and signed for the exact report hash before finalization.

No population satisfaction, statistical significance, unique-customer counts, causality, confirmed incidents, loss estimates or complete-coverage claims follow from these samples. Compare English and Chinese views to assess composition; validate candidate journeys against telemetry, release/device information and support cases.
""")
    write("data_dictionary.md","""
# V3 data dictionary

| Field / file | Meaning |
|---|---|
| record_key, review_id, app_id, platform | Source identity; record_key is unique within the saved merged set. |
| text, title | Verbatim body and optional Apple title; title may be null. |
| rating | Source integer 1–5. |
| review_timestamp_seconds | Source Unix seconds; sort key descending. |
| review_time_hk, review_time_utc | The same instant with explicit timezone. |
| collected_at_utc | Capture time, distinct from review date. |
| request_language, request_country | Retrieval locale and HK storefront; not language/location proof. |
| language_status, language_method | Preserved original English detector decision. |
| analysis_language, analysis_language_method | V3 routing: english / chinese / mixed / excluded, with reason. |
| within_six_month_window | HKT half-open date-window decision. |
| source_url | Public review or listing link; Apple usually lacks a direct review permalink. |
| raw_response_workspace_path, raw_item_index, raw_entry_index | Exact raw file and source position, relative to v3/. |
| source_observations | Capture references per review ID, retained through deduplication. |
| rating_sentiment | Star-based negative / neutral / positive proxy. |
| text_sentiment_rule | Supplementary English lexicon; Chinese/mixed = not_evaluated_chinese. |
| text_sentiment_evaluated_count | English-only denominator for supplementary text polarity. |
| themes, theme_labels | Multi-label keyword mentions, not confirmed complaints. |
| short_text_for_theme_review | At most 4 Latin words and at most 8 Han characters. |
| language_scope | all / english / chinese (includes mixed) / mixed (subset). |
| review_count, mean_rating | Group denominator and review sample mean, not lifetime listing rating. |
| negative_count_rating_1_2, negative_rate_rating_1_2 | Low-star record count and count / group reviews. |
| theme_mentions, theme_mention_rate | Topic hits and hits / bank-store-language reviews. |
| theme_negative_count, theme_negative_rate | Low-star hits and low-star hits / theme mentions. |
| benchmark_deltas | SC minus HSBC or BOCHK, within the same store/language. |
| data/qa/exclusions | Outside-window or unsupported/uncertain language records. |
| data/qa/capture_variants | Alternate snapshots with differing source-content fingerprints. |

CSV and JSON share row order; arrays/objects are JSON strings in CSV/Excel. CSV is faithful text and can contain formula-looking comments; Excel is the typed, non-executable workbook for spreadsheet browsing. Empty rate/mean denominators are null in JSON and N/A in the HTML.
""")
    write("checkpoint_A_source_feasibility.md",f"""
# Checkpoint A — V3 source feasibility

Requirement: include Chinese-language customer reviews; preserve English manager delivery, HSBC HK + BOCHK benchmarks, separate stores and the existing window.

Verified app IDs from the preserved configuration: SC Google com.scb.breezebanking.hk / Apple 445795688; HSBC hk.com.hsbc.hsbchkmobilebanking / 1164066737; BOCHK com.bochk.app.aos / 1534534188. Live zh-HK and zh-CN Google requests completed for all three on 22 October. Apple HK saved feeds already contain Chinese and are reused. Sources are bounded and are suitable for sample monitoring; complete history is not established.
""")
    write("checkpoint_B_data_collection_and_quality.md",f"""
# Checkpoint B — V3 collection and quality

Imported 6,378 unique V2 records and their referenced raw evidence; added {s['new_locale_observations']:,} Chinese-locale Google observations. Six jobs completed, stopped on older-page boundaries or endpoint exhaustion. Summary and each raw HTTP response are saved under data/chinese_collection/; no Apple recollection was necessary.

Saved unique records: {s['unique_fetched_records']:,}; window all-language records: {s['window_all_languages']:,}; selected bilingual records: {s['included_records']:,}; language exclusions in the window: {s['window_all_languages']-s['included_records']}. Duplicate observations: {s['duplicate_observations']}; capture variants: {s['capture_variant_count']}. Every source record retains capture time, review time, parameters and raw reference. V1 and V2 are protected by 2,020 recorded hashes.

{table}
""")
    write("checkpoint_C_data_preparation.md",f"""
# Checkpoint C — V3 preparation

Stored originals unchanged; routed scripts and reviewed exact English boundary phrases; filtered HKT dates; deduplicated source IDs; sorted newest first. Included {s['language_counts']['english']} English, {s['language_counts']['chinese']} Chinese and {s['language_counts']['mixed']} mixed records. Mixed belongs to the Chinese-inclusive view. All 418 V2 English fingerprints match.

Exports: merged source/all-language tables; bilingual source table; label table; two store-level and six bank/store tables; exclusions, repeated text, variants and coverage. Original detector status remains distinct from V3 analysis_language. The total source table includes older empty bodies as evidence; they do not enter analysis.
""")
    write("checkpoint_D_feedback_analysis.md",f"""
# Checkpoint D — V3 analysis

Primary rating sentiment and eleven bilingual multi-label themes were recomputed for four language views, three banks and two separate stores: 24 metric groups, 264 theme rows, 168 month rows and 16 benchmark comparisons. Empty groups retain null rates. Chinese/mixed text sentiment is not evaluated with the English lexicon.

The Codex agent read {s['sample_count']} selected comments and documented individual judgments and limitations in manual_review.json, bound to sample and source fingerprints. This is agent review, not independent human labeling. See executive_summary.md for store-specific findings and methodology.md for limitations.
""")
    write("checkpoint_E_report_and_validation.md","""
# Checkpoint E — V3 report and validation

report_customer_feedback_v3.html is a standalone English interface with global store and language selectors and a newest-first original-comment browser. Bank, rating, sentiment, topic and Unicode search filters operate within the selected store/language. Source text is inserted as literal text. No usernames, replies, remote scripts or remote assets are embedded.

data/reviews_v3.xlsx has separate store review sheets and scope-specific metrics. Verification results are in validation/static_results.json and validation/browser_results.json; they must match this exact HTML hash. Screenshots and the actual agent visual-inspection record are under screenshots/ and validation/. Checkpoint F and manifest.json are written only after those checks and inspection pass.
""")
