# Checkpoint C — V3 preparation

Stored originals unchanged; routed scripts and reviewed exact English boundary phrases; filtered HKT dates; deduplicated source IDs; sorted newest first. Included 497 English, 1122 Chinese and 63 mixed records. Mixed belongs to the Chinese-inclusive view. All 418 V2 English fingerprints match.

Exports: merged source/all-language tables; bilingual source table; label table; two store-level and six bank/store tables; exclusions, repeated text, variants and coverage. Original detector status remains distinct from V3 analysis_language. The total source table includes older empty bodies as evidence; they do not enter analysis.
