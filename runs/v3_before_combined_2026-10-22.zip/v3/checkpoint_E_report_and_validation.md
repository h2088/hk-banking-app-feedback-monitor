# Checkpoint E — V3 report and validation

report_customer_feedback_v3.html is a standalone English interface with global store and language selectors and a newest-first original-comment browser. Bank, rating, sentiment, topic and Unicode search filters operate within the selected store/language. Source text is inserted as literal text. No usernames, replies, remote scripts or remote assets are embedded.

data/reviews_v3.xlsx has separate store review sheets and scope-specific metrics. Verification results are in validation/static_results.json and validation/browser_results.json; they must match this exact HTML hash. Screenshots and the actual agent visual-inspection record are under screenshots/ and validation/. Checkpoint F and manifest.json are written only after those checks and inspection pass.
